﻿using BlazorApp.Server.Interfaces;
using BlazorApp.Server.Models;
using BlazorApp.Shared.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace BlazorApp.Server.Services
{
    public class UserManager : IUser
    {
        readonly DatabaseContext _dbContext = new();

        public UserManager(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        //To Get all user details   
        public List<User> GetUserDetails()
        {
            var results = (from c in _dbContext.Users
                           join cn in _dbContext.Country on c.CountryId equals cn.CountryId
                           join ct in _dbContext.States on c.StateId equals ct.StatesId
                           //  join sect in db.Sectors on c.SectorID equals sect.ID
                           // where (c.CountryID == cn.ID) && (c.CityID == ct.ID) && (c.SectorID == company.SectorID) && (company.SectorID == sect.ID)
                           select new User
                           {
                               Userid = c.Userid,
                               Username = c.Username,
                               Address = c.Address,
                               Cellnumber = c.Cellnumber,
                               Emailid = c.Emailid,
                               CountryId = cn.CountryName,
                               StateId = ct.StateName
                           }
                           ).ToList();


            return results;
            //try
            //{
                
            //    return _dbContext.Users.ToList();//ountry = cn.CountryName, States = ct.StateName, c.Userid
            //}
            //catch
            //{
            //    throw;
            //}
        }

        //To Add new user record     
        public void AddUser(User user)
        {
            try
            {
                _dbContext.Users.Add(user);
                _dbContext.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        //To Update the re'An error occurred while saving the entity changes. See the inner exception cords of a particluar user    
        public void UpdateUserDetails(User user)
        {
            try
            {
                _dbContext.Entry(user).State = EntityState.Modified;
                _dbContext.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        //Get the details of a particular user    
        public User GetUserData(int id)
        {
            try
            {
                User? user = _dbContext.Users.Find(id);
                //User dealercontacts = from  in DealerContact
                //                     join dealer in Dealer on contact.DealerId equals dealer.ID
                //                     select contact;

                var results = (from c in _dbContext.Users
                               join cn in _dbContext.Country on c.CountryId equals cn.CountryId
                               join ct in _dbContext.States on c.StateId equals ct.StatesId
                               //  join sect in db.Sectors on c.SectorID equals sect.ID
                               where ( c.Userid==id)
                               select new User
                               {
                                   Userid = c.Userid,
                                   Username = c.Username,
                                   Address = c.Address,
                                   Cellnumber = c.Cellnumber,
                                   Emailid = c.Emailid,
                                   CountryId = cn.CountryName,
                                   StateId = ct.StateName
                               }
                          ).ToList();

                if (user != null)
                {
                    return user;
                }
                else
                {
                    throw new ArgumentNullException();
                }
            }
            catch
            {
                throw;
            }
        }

        //To Delete the record of a particular user    
        public void DeleteUser(int id)
        {
            try
            {
                User? user = _dbContext.Users.Find(id);

                if (user != null)
                {
                    _dbContext.Users.Remove(user);
                    _dbContext.SaveChanges();
                }
                else
                {
                    throw new ArgumentNullException();
                }
            }
            catch
            {
                throw;
            }
        }

        public List<Country> GetAllCountries()
        {
            try
            {
                return _dbContext.Country.ToList();
            }
            catch
            {
                throw;
            }
        }

        public List<States> GetStateData(string id)
        {
            try
            {
                List<States> lstCity = new List<States>();
                lstCity = (from StateName in _dbContext.States where StateName.CountryId == id select StateName).ToList();

                return lstCity;
            }
            catch
            {
                throw;
            }
        }
    }
}
