﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorApp.Shared.Models
{
    public class User
    {
        public int Userid { get; set; }
        [Required]
        public string Username { get; set; } = null!;

        public string Address { get; set; } = null!;

        [Required]
        [StringLength(10)]
        public string Cellnumber { get; set; } = null!;

        public string Emailid { get; set; } = null!;

        [Required]
        public string CountryId { get; set; } = null!;

        [Required]
        public string StateId { get; set; } = null!;
    }

    public partial class Country
    {
        public Country()
        {
            States = new HashSet<States>();
        }

        public string CountryId { get; set; }
        public string CountryName { get; set; }

        public ICollection<States> States { get; set; }
    }
    public partial class States
    {
        public string StatesId { get; set; }
        public string CountryId { get; set; }
        public string StateName { get; set; }

        public Country Country { get; set; }
    }
}
